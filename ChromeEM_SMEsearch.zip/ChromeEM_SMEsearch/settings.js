// Journal settings
const JOURNAL_SETTINGS = {
//--------------------------------------------------------------------------------
  'www.editorialmanager.com/mtcomm': { // Journal address
    prefix: 'MTCOMM', // Journal prefix
    colors: { // List of digits, to chose new colors, search 'color selector' on google (HEX codes)
      // Format: 'digit': 'color' (add , if not the last one)
      '1': '#3b65ff', // Blue
      '2': '#8bc34a',  // Green
	  '3': '#009688', // Teal
	  '4': '#ff9800', // Orange
	  '5': '#e91e63', // Pink
	  '6': '#00bcd4', // Cyan
	  '7': '#fa6e64', // Red
	  '8': '#ffeb3b', // Yellow
	  '9': '#e858f5', // Violet
      '0': '#9c27b0'  // Purple //Last doesn't have a , at the end !
    },
    defaultColor: '#ffeb3b' // Keep this line unchanged
  },
//--------------------------------------------------------------------------------
  'www.editorialmanager.com/jcis': {
    prefix: 'JCIS',
    colors: {
      '0': '#ff9800', // Orange
      '1': '#e91e63', // Pink
      '2': '#00bcd4', // Cyan
      '3': '#8bc34a'  // Light Green //Last doesn't have a , at the end !
    },
    defaultColor: '#ffeb3b' // Keep this line unchanged
  },
//--------------------------------------------------------------------------------
  'www.editorialmanager.com/jalcom': {
    prefix: 'JALCOM',
    colors: {
      '4': '#f44336' // Red //Last doesn't have a , at the end !
    },
    defaultColor: '#ffeb3b' // Keep this line unchanged
  } //Last doesn't have a , at the end !
//--------------------------------------------------------------------------------
};
