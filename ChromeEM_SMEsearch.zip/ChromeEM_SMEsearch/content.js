// Global variables
var processedNodes = new Set();
var highlights = [];
var keywords = []; // Will be set based on domain
var manuscriptPrefix = ''; // Will be set based on domain
var retryCount = 0;
var MAX_RETRIES = 30;
var isProcessing = false;

// Initialize content script
function initialize() {
  console.log('\n=== Extension Initializing ===');
  console.log('Current URL:', window.location.href);
  console.log('Document readyState:', document.readyState);
  
  const domain = getDomain(window.location.href);
  console.log('Domain:', domain);
  
  if (domain && JOURNAL_SETTINGS[domain]) {
    const settings = JOURNAL_SETTINGS[domain];
    keywords = settings.keywords;
    manuscriptPrefix = settings.prefix;
    console.log('Using settings for domain:', domain);
    console.log('- Prefix:', manuscriptPrefix);
    console.log('- Keywords:', keywords);
    // Process main document and iframes
    processAllFrames();
    setupFrameObservers();
  } else {
    console.log('Not a supported Editorial Manager domain');
  }
}

function getDomain(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    if (hostname.includes('editorialmanager.com')) {
      // Get the full domain including the journal part
      const fullDomain = hostname + '/' + url.split('/')[3].toLowerCase();
      console.log('Full domain:', fullDomain);
      return fullDomain;
    }
  } catch (e) {
    console.error('Error parsing URL:', e);
  }
  return null;
}

function processManuscriptNumbers(element) {
  if (processedNodes.has(element)) return 0;
  
  let count = 0;
  const text = element.textContent;
  const manuscriptPattern = /[A-Z]+-(?:D-)?(?:\d{2}-)?(?:\d{2,5})(?:R\d+)?/g;
  let match;
  
  console.log('\n=== Processing Element ===');
  console.log('Element text:', text);
  
  while ((match = manuscriptPattern.exec(text)) !== null) {
    const manuscriptNumber = match[0];
    
    // Extract the last digit before any R
    const numberPart = manuscriptNumber.replace(/R\d+$/, ''); // Remove R and following digits if present
    const lastDigit = numberPart.match(/\d$/)[0]; // Get the last digit
    
    console.log('\nChecking manuscript:', manuscriptNumber);
    console.log('Last digit:', lastDigit);
    
    // Get settings for current domain
    const domain = getDomain(window.location.href);
    const settings = JOURNAL_SETTINGS[domain];
    
    // Check if this digit should be highlighted
    const shouldHighlight = settings?.colors ? lastDigit in settings.colors : 
                          (settings?.keywords ? settings.keywords.includes(lastDigit) : false);
    
    console.log('Should highlight:', shouldHighlight);
    
    // Create highlight
    const span = document.createElement('span');
    span.className = 'manuscript-highlight';
    
    if (shouldHighlight) {
      console.log('MATCH - Highlighting manuscript:', manuscriptNumber);
      if (settings?.colors) {
        // Use the specific color for this digit, or fall back to defaultColor or yellow
        span.style.backgroundColor = settings.colors[lastDigit] || settings.defaultColor || '#ffeb3b';
      } else {
        // Fallback for old settings format
        span.style.backgroundColor = settings?.color || '#ffeb3b';
      }
    } else {
      console.log('NO MATCH - Highlighting in gray:', manuscriptNumber);
      span.style.backgroundColor = '#e0e0e0'; // Gray for non-matching
    }
    
    span.style.color = '#000000';
    span.style.padding = '2px 4px';
    span.style.borderRadius = '3px';
    span.textContent = manuscriptNumber;
    
    // Replace text with highlight
    const range = document.createRange();
    range.setStart(element.firstChild, match.index);
    range.setEnd(element.firstChild, match.index + manuscriptNumber.length);
    range.deleteContents();
    range.insertNode(span);
    
    highlights.push(span);
    count++;
  }
  
  processedNodes.add(element);
  console.log(`Processed element, highlighted ${count} manuscripts`);
  return count;
}

function processAllFrames() {
  console.log('\n=== Processing All Frames ===');
  
  // Process main document
  processContent(document);
  
  // Process all iframes
  const frames = document.querySelectorAll('iframe');
  console.log('Found frames:', frames.length);
  
  frames.forEach((frame, index) => {
    try {
      console.log(`\n=== Analyzing Frame ${index} ===`);
      const frameDoc = frame.contentDocument || frame.contentWindow.document;
      
      // Log frame details
      console.log('Frame URL:', frameDoc.URL);
      console.log('Frame ready state:', frameDoc.readyState);
      
      // Check for our target elements
      const elements = {
        nonfixedData: frameDoc.querySelector('.fg-nonfixed-data'),
        fgData: frameDoc.querySelector('.fg-data'),
        fgRows: frameDoc.querySelector('.fg-rows'),
        fgTable: frameDoc.querySelector('.fg-table'),
        anyTable: frameDoc.querySelector('table'),
        visibleRecords: frameDoc.querySelector('[data-bind="visible: $data.HasAnyRecords()"]'),
        gridRendered: frameDoc.querySelector('[data-bind*="IsGridRendered"]')
      };
      
      console.log('\nFound elements:', 
        Object.entries(elements)
          .map(([key, el]) => `\n- ${key}: ${el ? 'YES' : 'NO'}`)
          .join('')
      );
      
      // If we found any table, log its structure
      const tables = frameDoc.querySelectorAll('table');
      console.log(`\nFound ${tables.length} tables in frame`);
      
      tables.forEach((table, tableIndex) => {
        console.log(`\nAnalyzing Table ${tableIndex}:`);
        console.log('- Classes:', table.className);
        console.log('- Parent classes:', table.parentElement?.className);
        console.log('- Rows:', table.rows.length);
        if (table.rows.length > 0) {
          console.log('- Cells in first row:', table.rows[0].cells.length);
          console.log('- Sample cell content:', table.rows[0].cells[0]?.textContent.trim());
        }
      });
      
      // Process the content
      processContent(frameDoc);
      
    } catch (e) {
      console.error('Error analyzing frame:', e);
    }
  });
}

function processContent(doc) {
  if (!doc || !doc.body) return;
  
  console.log('\n=== Processing Document Content ===');
  console.log('Document URL:', doc.URL);
  console.log('Current keywords:', keywords);
  
  // Clear previous elements
  elementsToProcess = [];
  
  // Try multiple ways to find our content
  const containers = [
    {
      element: doc.querySelector('.fg-nonfixed-data'),
      name: 'fg-nonfixed-data'
    },
    {
      element: doc.querySelector('.fg-data'),
      name: 'fg-data'
    },
    {
      element: doc.querySelector('.fg-rows'),
      name: 'fg-rows'
    },
    {
      element: doc.querySelector('[data-bind="visible: $data.HasAnyRecords()"]'),
      name: 'HasAnyRecords container'
    }
  ];
  
  console.log('\nChecking potential containers:');
  containers.forEach(({element, name}) => {
    if (element) {
      console.log(`\nFound ${name}:`);
      console.log('- Children:', element.children.length);
      console.log('- Contains table:', !!element.querySelector('table'));
      
      const table = element.querySelector('table');
      if (table) {
        findManuscriptsInTable(table, name);
      }
    }
  });
  
  // Also check all tables in the document
  const allTables = doc.querySelectorAll('table');
  console.log(`\nTotal tables in document: ${allTables.length}`);
  
  allTables.forEach((table, index) => {
    console.log(`\nProcessing table ${index}:`);
    findManuscriptsInTable(table, `table-${index}`);
  });
  
  // Now process all found elements
  console.log(`\n=== Processing ${elementsToProcess.length} elements ===`);
  elementsToProcess.forEach(element => {
    if (!processedNodes.has(element)) {
      processManuscriptNumbers(element);
    }
  });
}

function findManuscriptsInTable(table, context) {
  console.log(`\nFinding manuscripts in ${context}:`);
  console.log('- Table classes:', table.className);
  
  const rows = table.querySelectorAll('tr');
  console.log('- Total rows:', rows.length);
  
  rows.forEach((row, rowIndex) => {
    if (window.getComputedStyle(row).display === 'none') return;
    
    const cells = row.querySelectorAll('td');
    
    cells.forEach(cell => {
      if (!cell.textContent || window.getComputedStyle(cell).display === 'none') return;
      
      const text = cell.textContent.trim();
      if (!text) return;
      
      // Check for manuscript number pattern
      if (/[A-Z]+-(?:D-)?(?:\d{2}-)?(?:\d{2,5})(?:R\d+)?/.test(text)) {
        console.log(`Found manuscript number in ${context}, row ${rowIndex}:`, text);
        elementsToProcess.push(cell);
      }
    });
  });
}

function cleanupHighlights() {
  highlights.forEach(highlight => {
    if (highlight && highlight.parentNode) {
      highlight.parentNode.textContent = highlight.parentNode.textContent;
    }
  });
  highlights = [];
  processedNodes = new Set();
}

function setupFrameObservers() {
  // Observe iframe additions to main document
  const frameObserver = new MutationObserver((mutations) => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeName === 'IFRAME') {
          try {
            const frameDoc = node.contentDocument || node.contentWindow.document;
            processContent(frameDoc);
            setupContentObserver(frameDoc);
          } catch (e) {
            console.error('Error processing new frame:', e);
          }
        }
      });
    });
  });
  
  frameObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Set up observers for existing frames
  const frames = document.querySelectorAll('iframe');
  frames.forEach(frame => {
    try {
      const frameDoc = frame.contentDocument || frame.contentWindow.document;
      setupContentObserver(frameDoc);
    } catch (e) {
      console.error('Error setting up frame observer:', e);
    }
  });
  
  // Also observe main document
  setupContentObserver(document);
}

function setupContentObserver(doc) {
  const observer = new MutationObserver(() => {
    processContent(doc);
  });
  
  observer.observe(doc.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
}

// Start the script
console.log('=== Content Script Loaded ===');
initialize();
