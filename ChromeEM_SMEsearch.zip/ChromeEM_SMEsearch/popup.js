document.addEventListener('DOMContentLoaded', () => {
  const prevButton = document.getElementById('prev');
  const nextButton = document.getElementById('next');
  const refreshButton = document.getElementById('refresh');
  const highlightButton = document.getElementById('highlight');
  const clearButton = document.getElementById('clear');
  const counter = document.getElementById('counter');

  function updateCounter(response) {
    if (response && response.total > 0) {
      counter.textContent = `${response.currentIndex + 1} of ${response.total}`;
      prevButton.disabled = false;
      nextButton.disabled = false;
    } else {
      counter.textContent = '0/0';
      prevButton.disabled = true;
      nextButton.disabled = true;
    }
  }

  function sendMessage(action) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.sendMessage(tabs[0].id, { action }, updateCounter);
      }
    });
  }

  function refreshHighlights() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'refresh' }, updateCounter);
      }
    });
  }

  function clearHighlights() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'clear' }, () => {
          counter.textContent = '0/0';
          prevButton.disabled = true;
          nextButton.disabled = true;
        });
      }
    });
  }

  function manualHighlight() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'highlight' }, updateCounter);
      }
    });
  }

  if (prevButton) prevButton.addEventListener('click', () => sendMessage('prev'));
  if (nextButton) nextButton.addEventListener('click', () => sendMessage('next'));
  if (refreshButton) refreshButton.addEventListener('click', refreshHighlights);
  if (highlightButton) highlightButton.addEventListener('click', manualHighlight);
  if (clearButton) clearButton.addEventListener('click', clearHighlights);

  // Initial counter update
  sendMessage('getCount');
});
